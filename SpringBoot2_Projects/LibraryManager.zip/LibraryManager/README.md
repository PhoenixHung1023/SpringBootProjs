# 图书管理系统（非前后端分离）
## 所用技术以及版本
- JDK 8
- SpringBoot 2.7.13
- Druid 1.2.8
- MyBatisPlus 3.4.3.4
- Vue 2.5.16
- jQuery 3.2.1
- axios 0.18

## 效果
- 图书信息：
  - 图书ID
  - 图书种类
  - 图书名字
  - 图书描述
- 增删改查 图书信息

