/*
 *项目名: SpringBoot2_Projects
 *文件名: Book
 *创建者: Phoenix1023
 *创建时间:2023/7/10 21:07
 *描述: TODO

 */

package com.phoenix.domain;

import lombok.Data;

@Data
public class Book {
    private Integer id;
    private String type;
    private String name;
    private String description;
}
