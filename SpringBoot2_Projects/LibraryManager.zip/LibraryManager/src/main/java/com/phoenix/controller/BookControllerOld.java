/*
 *项目名: SpringBoot2_Projects
 *文件名: BookController
 *创建者: Phoenix1023
 *创建时间:2023/7/14 21:09
 *描述: TODO

 */

package com.phoenix.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.phoenix.domain.Book;
import com.phoenix.service.IBookService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//@RestController
@RequestMapping("/books")
public class BookControllerOld {

    private final IBookService bookService;

    public BookControllerOld(IBookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping
    public List<Book> getAll() {
        return bookService.list();
    }

    @PostMapping
    public Boolean save(@RequestBody Book book) {
        return bookService.save(book);
    }

    @PutMapping
    public Boolean update(@RequestBody Book book) {
        return bookService.modify(book);
    }

    @DeleteMapping("/{id}")
    public Boolean delete(@PathVariable Integer id) {
        return bookService.delete(id);
    }

    @GetMapping("/{id}")
    public Book getById(@PathVariable Integer id) {
        return bookService.getById(id);
    }

    @GetMapping("/{currentPage}/{pageSize}")
    public IPage<Book> getPage(
            @PathVariable Integer currentPage,
            @PathVariable Integer pageSize) {
        return  bookService.getPage(currentPage, pageSize);
    }
}
