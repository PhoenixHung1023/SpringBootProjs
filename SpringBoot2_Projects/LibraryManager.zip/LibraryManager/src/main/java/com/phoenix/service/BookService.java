/*
 *项目名: SpringBoot2_Projects
 *文件名: BookService
 *创建者: Phoenix1023
 *创建时间:2023/7/13 20:32
 *描述: TODO

 */

package com.phoenix.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.phoenix.domain.Book;

import java.util.List;

public interface BookService {
    Boolean save(Book book);
    Boolean update(Book book);
    Boolean delete(Integer id);
    Book getById(Integer id);
    List<Book> getAll();
    IPage<Book> getPage(int currentPage, int size);
}
