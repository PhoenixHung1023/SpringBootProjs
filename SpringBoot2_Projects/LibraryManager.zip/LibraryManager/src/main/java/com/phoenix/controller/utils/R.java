/*
 *项目名: SpringBoot2_Projects
 *文件名: R
 *创建者: Phoenix1023
 *创建时间:2023/7/14 22:13
 *描述: TODO

 */

package com.phoenix.controller.utils;

import lombok.Data;

@Data
public class R {
    private Object data;
    private Integer code;
    private String msg;
    private Boolean flag;

    public R() {
    }

    public R(Integer code, Boolean flag) {
        this.code = code;
        this.flag = flag;
    }

    public R(Object data, Integer code) {
        this.code = code;
        this.data = data;
    }

    public R(Boolean flag, String msg) {
        this.flag = flag;
        this.msg = msg;
    }

    public R(Integer code, Object data, String msg,Boolean flag) {
        this.code = code;
        this.data = data;
        this.msg = msg;
        this.flag = flag;
    }

}
