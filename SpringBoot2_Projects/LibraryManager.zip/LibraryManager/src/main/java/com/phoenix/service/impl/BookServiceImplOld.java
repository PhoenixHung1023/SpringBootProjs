/*
 *项目名: SpringBoot2_Projects
 *文件名: BookServiceImpl
 *创建者: Phoenix1023
 *创建时间:2023/7/13 20:36
 *描述: TODO

 */

package com.phoenix.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.phoenix.dao.BookDao;
import com.phoenix.domain.Book;
import com.phoenix.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

//@Service
public class BookServiceImplOld implements BookService {

    private final BookDao bookDao;

    public BookServiceImplOld(BookDao bookDao) {
        this.bookDao = bookDao;
    }

    @Override
    public Boolean save(Book book) {
        return bookDao.insert(book) > 0;
    }

    @Override
    public Boolean update(Book book) {
        return bookDao.updateById(book) > 0;
    }

    @Override
    public Boolean delete(Integer id) {
        return bookDao.deleteById(id) > 0;
    }

    @Override
    public Book getById(Integer id) {
        return bookDao.selectById(id);
    }

    @Override
    public List<Book> getAll() {
        return bookDao.selectList(null);
    }

    @Override
    public IPage<Book> getPage(int currentPage, int size) {
        IPage<Book> page = new Page<>(currentPage, size);
        return bookDao.selectPage(page, null);
    }
}
