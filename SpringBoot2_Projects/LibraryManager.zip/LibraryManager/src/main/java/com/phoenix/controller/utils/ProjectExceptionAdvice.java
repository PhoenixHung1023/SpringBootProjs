package com.phoenix.controller.utils;/*
 *项目名: SpringBoot2_Projects
 *文件名: ProjectException
 *创建者: Phoenix1023
 *创建时间:2023/7/18 22:16
 *描述: TODO
 */

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

// 作为SpringMVC的异常处理器
//@ControllerAdvice
@RestControllerAdvice
public class ProjectExceptionAdvice {

    // 拦截所有的异常信息
    @ExceptionHandler
    public R doException(Exception ex) {
        // 记录日志
        // 通知运维
        // 通知开发
        ex.printStackTrace(); // 控制台能看到异常信息
        return new R(false, "服务器故障，请稍后再试！");
    }

}
