/*
 *项目名: SpringBoot2_Projects
 *文件名: BookController
 *创建者: Phoenix1023
 *创建时间:2023/7/14 21:09
 *描述: TODO

 */

package com.phoenix.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.phoenix.controller.utils.Code;
import com.phoenix.controller.utils.R;
import com.phoenix.domain.Book;
import com.phoenix.service.IBookService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    private final IBookService bookService;

    public BookController(IBookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping
    public R getAll() {
        List<Book> bookList = bookService.list();
        Boolean flag = bookList != null;
        Integer code = flag ? Code.GET_OK : Code.GET_ERR;
        String msg = flag ? "" : "数据查询失败，请重试！";
        return new R(code, bookList, msg, flag);
    }

    @PostMapping
    public R save(@RequestBody Book book) {
        boolean flag = bookService.save(book);
        return new R(flag ? Code.SAVE_OK : Code.SAVE_ERR,null, "", flag);
    }

    @PutMapping
    public R update(@RequestBody Book book) {
        Boolean flag = bookService.modify(book);
        return new R(flag ? Code.UPDATE_OK : Code.UPDATE_ERR,null, "", flag);
    }

    @DeleteMapping("/{id}")
    public R delete(@PathVariable Integer id) {
        Boolean flag = bookService.delete(id);
        return new R(flag ? Code.DELETE_OK : Code.DELETE_ERR,null, "", flag);
    }

    @GetMapping("/{id}")
    public R getById(@PathVariable Integer id) {
        Book book = bookService.getById(id);
        Boolean flag = book != null;
        Integer code = flag ? Code.GET_OK : Code.GET_ERR;
        String msg = flag ? "" : "数据查询失败，请重试！";
        return new R(code, book, msg, flag);
    }

/*    @GetMapping("/{currentPage}/{pageSize}")
    public R getPage(
            @PathVariable Integer currentPage,
            @PathVariable Integer pageSize) {
        IPage<Book> page = bookService.getPage(currentPage, pageSize);
        Boolean flag = page != null;
        Integer code = flag ? Code.GET_OK : Code.GET_ERR;
        String msg = flag ? "" : "数据查询失败，请重试！";
        // 若当前页码值 大于 总页码值，则重新执行查询操作，使用最大页码值作为当前页码值
        if (currentPage > page.getPages()) {
            page = bookService.getPage((int) page.getPages(), pageSize);
        }
        return new R(code, page, msg, flag);
    }*/
@GetMapping("/{currentPage}/{pageSize}")
public R getPage(
        @PathVariable Integer currentPage,
        @PathVariable Integer pageSize,
        Book book) {
        IPage<Book> page = bookService.getPage(currentPage, pageSize, book);
        Boolean flag = page != null;
        Integer code = flag ? Code.GET_OK : Code.GET_ERR;
        String msg = flag ? "" : "数据查询失败，请重试！";
        // 若当前页码值 大于 总页码值，则重新执行查询操作，使用最大页码值作为当前页码值
        if (currentPage > page.getPages()) {
            page = bookService.getPage((int) page.getPages(), pageSize, book);
        }
        return new R(code, page, msg, flag);
    }
}
